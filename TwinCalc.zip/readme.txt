software:	TwinCalc

Title:		TwinCalc: a multitool for calcite twinning based stress analysis

Author:		Ji�� Rez; Department of Geological Sciences, Faculty of Science, Masaryk University, Kotl��sk� 2, 61137, Brno, Czech Republic.  jura@eltekto.cz
